package com.yash.model;

public class Student {
	int sid,cityid;
	int phoneno_stud,phoneno_parent;
	String DOJ,DOB;
	String email_student,email_parent;
	String firstname,lastname,fathername,mothername,gender;
	String classname,section;
	String aad1,add2,city;
	
	public Student() {
		super();
	}

	public Student(int sid, int cityid, int phoneno_stud, int phoneno_parent, String dOJ, String dOB,
			String email_student, String email_parent, String firstname, String lastname, String fathername,
			String mothername, String gender, String classname, String section, String aad1, String add2, String city) {
		super();
		this.sid = sid;
		this.cityid = cityid;
		this.phoneno_stud = phoneno_stud;
		this.phoneno_parent = phoneno_parent;
		this.DOJ = dOJ;
		this.DOB = dOB;
		this.email_student = email_student;
		this.email_parent = email_parent;
		this.firstname = firstname;
		this.lastname = lastname;
		this.fathername = fathername;
		this.mothername = mothername;
		this.gender = gender;
		this.classname = classname;
		this.section = section;
		this.aad1 = aad1;
		this.add2 = add2;
		this.city = city;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public int getCityid() {
		return cityid;
	}

	public void setCityid(int cityid) {
		this.cityid = cityid;
	}

	public int getPhoneno_stud() {
		return phoneno_stud;
	}

	public void setPhoneno_stud(int phoneno_stud) {
		this.phoneno_stud = phoneno_stud;
	}

	public int getPhoneno_parent() {
		return phoneno_parent;
	}

	public void setPhoneno_parent(int phoneno_parent) {
		this.phoneno_parent = phoneno_parent;
	}

	public String getDOJ() {
		return DOJ;
	}

	public void setDOJ(String dOJ) {
		DOJ = dOJ;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getEmail_student() {
		return email_student;
	}

	public void setEmail_student(String email_student) {
		this.email_student = email_student;
	}

	public String getEmail_parent() {
		return email_parent;
	}

	public void setEmail_parent(String email_parent) {
		this.email_parent = email_parent;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getFathername() {
		return fathername;
	}

	public void setFathername(String fathername) {
		this.fathername = fathername;
	}

	public String getMothername() {
		return mothername;
	}

	public void setMothername(String mothername) {
		this.mothername = mothername;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getClassname() {
		return classname;
	}

	public void setClassname(String classname) {
		this.classname = classname;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getAad1() {
		return aad1;
	}

	public void setAad1(String aad1) {
		this.aad1 = aad1;
	}

	public String getAdd2() {
		return add2;
	}

	public void setAdd2(String add2) {
		this.add2 = add2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	
	

}