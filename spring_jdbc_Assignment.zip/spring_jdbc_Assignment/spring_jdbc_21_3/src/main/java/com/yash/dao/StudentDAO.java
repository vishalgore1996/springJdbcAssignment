package com.yash.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import com.yash.model.*;

public class StudentDAO {
	JdbcTemplate objJDBC;

	public JdbcTemplate getObjJDBC() {
		return objJDBC;
	}

	public void setObjJDBC(JdbcTemplate objJDBC) {
		this.objJDBC = objJDBC;
	}

	public int saveStu(Student objS) {
		String query = "insert into student (sid,classname,cityid,section,DOJ,firstname,lastname,fathername,mothername,gender,DOB,phoneno_parent,phoneno_stud,email_parent,email_student,aad1,add2) values ('"
				+ objS.getSid() + "','" + objS.getClassname() +"','"+objS.getCityid()+"','" + objS.getSection() + "','" + objS.getDOJ() + "' ,'" + objS.getFirstname() +

				"','" + objS.getLastname() + "','" + objS.getFathername() + "','" + objS.getMothername() + "','"
				+ objS.getGender() + "','" + objS.getDOB() + "','"
				+ objS.getPhoneno_parent() + "','" + objS.getPhoneno_stud() + "','" + objS.getEmail_parent() + "','"
				+ objS.getEmail_student() + "','"+objS.getAad1()+"','"+objS.getAdd2()+"')";
		int no;
		no = objJDBC.update(query);
		return no;
	}
		public int stuCity(Student objS) {
	 String query= "insert into city(cityid,city) values ('"+objS.getCityid()+"','"+objS.getCity()+"')"; 

		int no;
		no = objJDBC.update(query);
		return no;
	}
	public int updateStudent(Student objS)
	{
		String query="update student set firstname='"+objS.getFirstname()+"',lastname='"+objS.getLastname()+"' where sid="+objS.getSid();
		int no;
		no =objJDBC.update(query);
		return no;
			
	}
	public int deleteStudent(int sid)
	{
		String query ="delete from student where sid="+sid;
		return objJDBC.update(query);
	}
}
