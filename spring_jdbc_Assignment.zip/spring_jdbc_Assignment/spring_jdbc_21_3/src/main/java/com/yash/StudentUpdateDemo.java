package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.Scanner;
import com.yash.dao.EmployeeDAO;
import com.yash.dao.StudentDAO;
import com.yash.model.*;

public class StudentUpdateDemo {
 public static void main(String s[])
 {	  
	 ApplicationContext objAC = new ClassPathXmlApplicationContext("applicationContext.xml");
	 StudentDAO objed = (StudentDAO) objAC.getBean("sdao");
	Student objS= new Student();
	objS.setFirstname("rahul");
	objS.setPhoneno_stud(8490);
	objS.setClassname("lotus");
		
	System.out.println("Total Record updated:- "+objed.updateStudent(objS));		 
	 }
 }