package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.dao.StudentDAO;
import com.yash.model.*;
import java.util.*;

public class StudentMain {
	public static void main(String s[]) {
		ApplicationContext objAC = new ClassPathXmlApplicationContext("applicationContext.xml");
		StudentDAO objst = (StudentDAO) objAC.getBean("sdao");
		Student objS = new Student();
		Scanner sc = new Scanner(System.in);
		String DOJ=" ",DOB=" ";
		int sid,cityid;
		int phoneno_stud = 0, phoneno_parent = 0;
		String email_student = " ", email_parent = " ";
		String firstname = " ", lastname = " ", fathername = " ", mothername = " ", gender = " ";
		String classname = " ", section = " ";
		String aad1 = " ", add2 = " ", city = " ";
		while (true) {
			System.out.println("Enter 1 : Insert student datails  2: city datails 3 : update datails  4:  delete");
			int ch = sc.nextInt();
			sc.nextLine();
			switch (ch) {
			case 1:
				while (true) {
					System.out.println("Enter a student id :");
					sid = sc.nextInt();

					System.out.println("Enter a class name :");
					classname = sc.next();
					System.out.println("Enter city Id :");
					cityid=sc.nextInt();
					System.out.println("Enter a section name :");
					section = sc.next();
					System.out.println("Enter a date of joining :");
					DOJ = sc.next();
					System.out.println("Enter a first name of student :");
					firstname = sc.next();
					System.out.println("Enter a last name of student :");
					lastname = sc.next();
					System.out.println("Enter a father name of student :");
					fathername = sc.next();
					System.out.println("Enter a mother name of student :");
					mothername = sc.next();
					System.out.println("Enter a Gender of student :");
					gender = sc.next();
					System.out.println("Enter a Date of birth of student :");
					DOB = sc.next();
					System.out.println("Enter a mobile no of parent:");
					phoneno_parent = sc.nextInt();
					System.out.println("Enter a mobile no of student :");
					phoneno_stud = sc.nextInt();
					System.out.println("Enter a mail id of parent :");
					email_parent = sc.next();
					System.out.println("Enter a mail id of student :");
					email_student = sc.next();
					System.out.println("Enter a address 1 of student");
					aad1 = sc.next();
					System.out.println("Enter a address 2 of student");
					add2 = sc.next();

					objS.setSid(sid);

					objS.setClassname(classname);
					objS.setCityid(cityid);
					objS.setSection(section);
					objS.setDOJ(DOJ);
					objS.setFirstname(firstname);
					objS.setLastname(lastname);
					objS.setFathername(fathername);
					objS.setMothername(mothername);
					objS.setGender(gender);
					objS.setDOB(DOB);
					objS.setPhoneno_parent(phoneno_parent);
					objS.setPhoneno_stud(phoneno_stud);
					objS.setEmail_parent(email_parent);
					objS.setEmail_student(email_student);
					objS.setAad1(aad1);
					objS.setAdd2(add2);
					System.out.println("Total record saved" + objst.saveStu(objS));
					System.out.println("want to do more 1 for yes 0 for no");
					ch = sc.nextInt();
					sc.nextLine();
					if (ch == 0)
						break;

				}
				break;
			case 2:
				while (true) {
					System.out.println("Enter cityid is :");
					cityid = sc.nextInt();
					System.out.println("Enter city of student");
					city = sc.next();
					

					objS.setCityid(cityid);
					objS.setCity(city);
					
					System.out.println("Total record saved" + objst.stuCity(objS));
					System.out.println("want to do more 1 for yes 0 for no");
					ch = sc.nextInt();
					sc.nextLine();
					if (ch == 0)
						break;

				}
				break;

			case 3:
				StudentDAO objed = (StudentDAO) objAC.getBean("sdao");

				
				objS.setSid(1);

				objS.setClassname("rose");
				objS.setCityid(3);
				objS.setSection("p");
				objS.setDOJ("21feb2020");
				objS.setFirstname("raj");
				objS.setLastname("dhan");
				objS.setFathername("rao");
				objS.setMothername("tara");
				objS.setGender("male");
				objS.setDOB("03march1997");
				objS.setPhoneno_parent(9978);
				objS.setPhoneno_stud(9530);
				objS.setEmail_parent("xyz");
				objS.setEmail_student("abc");
				objS.setAad1("bmnagar");
				objS.setAdd2("deoli");
				System.out.println("Total Record updated:- " + objed.updateStudent(objS));
				break;
			case 4:
				StudentDAO objed1 = (StudentDAO) objAC.getBean("sdao");

				System.out.println("Total Record Deleted:- " + objed1.deleteStudent(2));
				break;

			default:
				System.out.println("Wrong choice");
			}
		}
	}
}